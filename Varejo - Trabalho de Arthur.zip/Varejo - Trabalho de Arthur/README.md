
**Lista de casos que devemos fazer:**

    1 caso de uso: cadastro de produto(inserir produtos);
    
    2 caso de uso: contabilidade do estoque (listar produtos);
    
    3 caso de uso: remoção do produto;
    
    4 caso de uso: procurar um determinado produto no estoque;
    
    5 caso de uso: cadastro de funcionario;
    
    6 caso de uso: remoção de funcionario;
    
    7 caso de uso: alterar especificação de funcionario;
    
    8 caso de uso: cadastro de fornecedor;
    
    9 caso de uso: remoção de fornecedor;
    
    10 caso de uso: alterar especificação do fornecedor;
    
    11 caso de uso: realiza venda;
    
    12 caso de uso: realiza pagamento de salario;

===============================================

**Nome dos Integrantes do Grupo:**

    Emanuel Lima Tomaz de Aquino;
    
    Erick Silva de Souza;
    
    Caio Antônio Andrade da Silva;
    
    Lucas Henrique Chaves da Silva.

===============================================

**Turma: ADS Manhã,** 

    3º período.

**Instituição**: 

    FICR.

